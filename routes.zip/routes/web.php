<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\CareemImportController;
use App\Http\Controllers\UberImportController;
use App\Http\Controllers\CaptainController;
use App\Http\Controllers\OtherPaymentController;
use App\Http\Controllers\TrafficController;
use App\Http\Controllers\DarbController;
use App\Http\Controllers\OtherController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SalikImportController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('login');
});

Route::group(['middleware' => 'auth'],function(){
    Route::get('/dashboard',[DashboardController::class, 'dashboard'])->name('dashboard');

    Route::get('careemimport', [CareemImportController::class, 'index']);
    Route::post('careemimport', [CareemImportController::class, 'store'])->name('careemimport');
    Route::get('savecareemimport', [CareemImportController::class, 'save'])->name('savecareemimport');

    Route::get('uberimport', [UberImportController::class, 'index']);
    Route::post('uberimport', [UberImportController::class, 'store'])->name('uberimport');
    Route::get('saveuberimport', [UberImportController::class, 'save'])->name('saveuberimport');

    Route::get('salikimport', [SalikImportController::class, 'index']);
    Route::post('salikimport', [SalikImportController::class, 'store'])->name('salikimport');
    Route::get('savesalikimport', [SalikImportController::class, 'save'])->name('savesalikimport');

    Route::resource('captain', CaptainController::class);
    Route::post('captainimageupload', [CaptainController::class, 'captainimageupload'])->name('captainimageupload');

    Route::resource('otherpayment', OtherPaymentController::class);

    Route::resource('darb', DarbController::class);
    Route::resource('traffic', TrafficController::class);
    Route::resource('other', OtherController::class);

    Route::get('report', [ReportController::class, 'index'])->name('report');
    Route::post('createreport', [ReportController::class, 'createreport'])->name('createreport');

    Route::resource('company', CompanyController::class);

    Route::resource('user', UserController::class);
    Route::get('profile', [UserController::class, 'profile'])->name('user.profile');
    Route::post('updateprofile', [UserController::class, 'updateprofile'])->name('user.updateprofile');
});

Route::view('login','login')->name('login');
//Route::get('/login',[LoginController::class, 'login'])->name('login');
Route::post('doLogin', [LoginController::class, 'doLogin'])->name('doLogin');
Route::get('logout',[LoginController::class,'logout'])->name('logout');

