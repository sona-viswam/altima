<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free"
>
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="card mb-4">
                        <h5 class="card-header">Traffic Expense</h5>
                        <div class="card-body">
                            <form id="formAccountSettings" method="POST" onsubmit="return false">
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <label for="date" class="form-label">Date</label>
                                        <input class="form-control" type="date" id="date" name="date"
                                               value="{{ date('Y-m-d') }}" autofocus="">
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label" for="country">Captain</label>
                                        <select id="country" class="select2 form-select">
                                            <option value="">Select</option>
                                            <option value="Australia">John</option>
                                            <option value="Bangladesh">Alex</option>
                                        </select>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="salary" class="form-label">Amount</label>
                                        <input type="text" class="form-control" id="salary" name="salary"
                                               placeholder="200" maxlength="6">
                                    </div>
                                </div>

                                <div class="mt-2">
                                    <button type="submit" class="btn btn-primary me-2">Save</button>
                                    <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
