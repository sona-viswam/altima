<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <link rel="stylesheet" media="screen" href="{{ URL::asset('assets/css/a4style.css') }}" />
    <link rel="stylesheet" media="print" href="{{ URL::asset('assets/css/a4printstyle.css') }}" />
    <style>        
        th, td {
        border-color: #ddd; 
        }
    </style>
</head>
<body>
<h2>{{ config('app.name')}}</h2>
<h4>Uber Imported Report </h4>
<table style="width:90%;">
    <thead>
        <th>#</th>
        <th >Driver UUID</th>
        <th>Driver first name</th>
        <th>Driver surname</th>
        <th>Total<br> earnings</th>
        <th>Refunds<br>& <br>Expenses</th>
        <th>Payouts : <br>Cash collected</th>
        <th>Paid to <br>third<br> parties</th>
    </thead>
    <tbody>
    @php($i=0)
    @forelse($data  as $key => $value)
        <tr>
        <td class="centertext">{{ ++$i }}</td>
        <td>{{ $value->driver_uuid }}</td>
        <td>{{ $value->driver_first_name }}</td>
        <td>{{ $value->driver_surname }}</td>
        <td class="righttext">{{ $value->total_earnings }}</td>
        <td class="righttext">{{ $value->refunds_expenses }}</td>
        <td class="righttext">{{ $value->payouts_cash_collected }}</td>
        <td class="righttext">{{ $value->paid_to_third_parties }}</td>
        </tr>
    @empty
        <tr>
            <td class ="text-center text-secondary mt-2" colspan="14">No data available now</td>
        </tr>
    @endforelse
    </tbody>
</table>
<h5>
    <div class="spinner-border text-primary me-2" role="status" id="loadDiv" style="display: none">
        <span class="visually-hidden">Loading...</span>
    </div>
    <a href="{{ route('saveuberimport') }}"class="btn btn-default" onclick="$(this).hide();$('#loadDiv').show();">Save</a> &nbsp;
    <a href="{{ route('uberimport') }}"class="btn btn-default">Back</a> &nbsp;
    <a href= "#" onClick="window.print(); return false;" class="btn btn-default">Print</a></h5>
</body>
</html>

