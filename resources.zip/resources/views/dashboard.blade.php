<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free"
>
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="row">

                        <div class="col-lg-4 col-md-4 order-1">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-6 mb-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="card-title d-flex align-items-start justify-content-between">
                                                <div class="avatar flex-shrink-0">
                                                    <img src="{{ asset('assets/img/icons/unicons/chart-success.png') }}" alt="chart success" class="rounded">
                                                </div>
                                            </div>
                                            <span class="fw-semibold d-block mb-1">Captain</span>
                                            <h3 class="card-title mb-2">{{ $captainCount }}</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-6 mb-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="card-title d-flex align-items-start justify-content-between">
                                                <div class="avatar flex-shrink-0">
                                                    <img src="{{ asset('assets/img/icons/unicons/wallet-info.png') }}" alt="chart success" class="rounded">
                                                </div>
                                            </div>
                                            <span class="fw-semibold d-block mb-1">Darb</span>
                                            <h3 class="card-title mb-2">{{ $darbamount }}</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-8 col-lg-4 order-3 order-md-2">
                            <div class="row">
                                <div class="col-6 mb-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="card-title d-flex align-items-start justify-content-between">
                                                <div class="avatar flex-shrink-0">
                                                    <img src="{{ asset('assets/img/icons/unicons/paypal.png') }}" alt="Credit Card" class="rounded">
                                                </div>
                                            </div>
                                            <span class="d-block mb-1">Traffic</span>
                                            <h3 class="card-title text-nowrap mb-2">{{ $trafficamount }}</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 mb-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="card-title d-flex align-items-start justify-content-between">
                                                <div class="avatar flex-shrink-0">
                                                    <img src="{{ asset('assets/img/icons/unicons/cc-primary.png') }}" alt="Credit Card" class="rounded">
                                                </div>
                                            </div>
                                            <span class="fw-semibold d-block mb-1">Other</span>
                                            <h3 class="card-title mb-2">{{ $otheramount}} </h3>
                                        </div>
                                    </div>
                                </div>
                                <!-- </div>
                <div class="row"> -->

                            </div>
                        </div>
                    </div>
                 </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
