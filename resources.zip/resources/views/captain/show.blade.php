<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free">
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <h4 class="fw-bold py-0 mb-4">Captain Account</h4>
                    @include('message')
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card mb-4">
                                <h5 class="card-header">Details</h5>
                                <div class="card-body">
                                        <div class="row">
                                            @if($captain->photo)
                                            <div class="mb-3 col-md-12">
                                                 <img src="{{ asset('upload/'.$captain->photo) }}" alt="user-avatar" class="d-block rounded" height="100" width="100" id="uploadedAvatar">
                                            </div>
                                            @endif
                                            <div class="mb-3 col-md-6">
                                                <label for="name" class="form-label">Control ID : </label>
                                                <span class="mb-0">{{ $captain->controlid }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="name" class="form-label">Uber UUID : </label>
                                                <span class="mb-0">{{ $captain->uuid }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="name" class="form-label">Careeem Captain ID : </label>
                                                <span class="mb-0">{{ $captain->captainid }}</span>
                                            </div>
                                            <hr class="my-3" />

                                            <div class="mb-3 col-md-6">
                                                <label for="name" class="form-label">Name : </label>
                                                <span class="mb-0">{{ $captain->fullname }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Email : </label>
                                                <span class="mb-0">{{ $captain->email }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">DOB : </label>
                                                <span class="mb-0">{{ $captain->dob }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Phone : </label>
                                                <span class="mb-0">{{  $captain->phone }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Gender : </label>
                                                <span class="mb-0">{{ ucfirst($captain->gender) }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Address : </label>
                                                <span class="mb-0">{{ $captain->address }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Salary : </label>
                                                <span class="mb-0">{{ $captain->salary }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Vehicle : </label>
                                                <span class="mb-0">{{ $captain->vehicle }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Car Expiry Date : </label>
                                                <span class="mb-0">{{ $captain->car_expiry_date }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Plate : </label>
                                                <span class="mb-0">{{ $captain->plate }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Loan Ends : </label>
                                                <span class="mb-0">{{ $captain->loanend }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Work P.Expiry : </label>
                                                <span class="mb-0">{{ $captain->workpermitexpiry }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                            <label for="email" class="form-label">Installment Amount : </label>
                                                <span class="mb-0">{{ $captain->installment }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                            <label for="email" class="form-label">Office Charge : </label>
                                                <span class="mb-0">{{ $captain->officecharge }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Created By : </label>
                                                <span class="mb-0">{{ $captain->mycreateduser?->name}}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Updatd By : </label>
                                                <span class="mb-0">{{ $captain->myupdateduser?->name}}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Created On : </label>
                                                <span class="mb-0">{{ date('d M Y', strtotime($captain->created_at)) }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Updated On : </label>
                                                <span class="mb-0">{{ date('d M Y', strtotime($captain->updated_at)) }}</span>
                                            </div>
                                            <div class="mt-2">
                                                <a class="btn btn-outline-primary" href="{{ route('captain.index') }}"> Back</a>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
