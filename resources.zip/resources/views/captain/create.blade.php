<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free"
>
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="card mb-4">
                        <h5 class="card-header">Captain Details</h5>
                        <!-- Account -->
                        <form action="{{ route('captain.store') }}" method="POST" enctype="multipart/form-data">@csrf
                        <div class="card-body">
                            <div class="d-flex align-items-start align-items-sm-center gap-4">
                                <div id="photodiv">
                                    <img src="{!! asset('assets/img/avatars/1.png') !!}" alt="user-avatar" class="d-block rounded"
                                         height="100" width="100" id="uploadedAvatar">
                                </div>
                                <div class="button-wrapper">
                                    <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                                        <span class="d-none d-sm-block">Upload photo</span>
                                        <i class="bx bx-upload d-block d-sm-none"></i>
                                        <input type="file" id="upload" name="photo" class="account-file-input" hidden=""
                                               accept="image/png, image/jpeg, image/gif">
                                    </label>
                                    <p class="text-muted mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                                </div>
                            </div>
                        </div>
                            <input type="hidden" id="myroute" value="{{ route('captainimageupload') }}">

                        <hr class="my-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="mb-3 col-md-6">
                                <label for="name" class="form-label">Control ID <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="text" id="controlid" name="controlid" value="{{ old('controlid') }}">
                                        <span style="color:red">@error('controlid'){{$message}}@enderror</span>
                                </div>

                            </div>

                                <div class="row">
                                <div class="mb-3 col-md-6">
                                        <label for="name" class="form-label">Uber UUID <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="text" id="uuid" name="uuid" autofocus="" value="{{ old('uuid') }}">
                                        <span style="color:red">@error('uuid'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="name" class="form-label">Careeem Captain ID <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="text" name="captainid" autofocus="" value="{{ old('captainid') }}">
                                        <span style="color:red">@error('captainid'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="name" class="form-label">First Name <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="text" id="firstname" name="firstname" autofocus="" value="{{ old('firstname') }}">
                                        <span style="color:red">@error('firstname'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="name" class="form-label">Last Name</label>
                                        <input class="form-control" type="text" name="lastname" autofocus="" value="{{ old('lastname') }}">
                                        <span style="color:red">@error('lastname'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="email" class="form-label">Email</label>
                                        <input class="form-control" type="email" name="email" id="email" value="{{ old('email') }}">
                                        <span style="color:red">@error('email'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="dob" class="form-label">DOB</label>
                                        <input class="form-control" type="date" name="dob" id="dob" max="{{ date('Y-m-d') }}" value="{{ old('dob') }}">
                                        <span style="color:red">@error('dob'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="email" class="form-label">Gender</label>
                                        <div class="col-md">
                                            <div class="form-check form-check-inline mt-3">
                                                <input class="form-check-input" type="radio" name="gender" id="gender" value="male" @checked(old('gender','male'))>
                                                <label class="form-check-label" for="gender">Male</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="gender" id="gender" value="female" @checked(old('gender','female'))>
                                                <label class="form-check-label" for="gender">Female</label>
                                            </div>
                                            <!-- <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="gender" id="gender" value="other" @checked(old('gender','other'))>
                                                <label class="form-check-label" for="gender">Other</label>
                                            </div> -->
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="email" class="form-label">Address</label>
                                        <textarea class="form-control" name="address" id="address" rows="3">{{ old('address') }}</textarea>
                                        <span style="color:red">@error('address'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="email" class="form-label">Phone <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="number" name="phone" id="phone" value="{{ old('phone') }}">
                                        <span style="color:red">@error('phone'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="email" class="form-label">Vehicle <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="text" name="vehicle" id="vehicle" value="{{ old('vehicle') }}">
                                        <span style="color:red">@error('vehicle'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <label for="car_expiry_date" class="form-label">CAR EXPIRY DATE <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="date" name="car_expiry_date" id="car_expiry_date" value="{{ old('car_expiry_date') }}">
                                        <span style="color:red">@error('car_expiry_date'){{$message}}@enderror</span>
                                    </div>
                                    
                                    <div class="mb-3 col-md-4">
                                        <label for="email" class="form-label">Plate <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="text" name="plate" id="plate" value="{{ old('plate') }}">
                                        <span style="color:red">@error('plate'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <label for="email" class="form-label">Loan End</label>
                                        <input class="form-control" type="date" name="loanend" id="loanend" value="{{ old('loanend') }}">
                                        <span style="color:red">@error('loanend'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <label  class="form-label">Installment</label>
                                        <input class="form-control" type="number" name="installment" id="installment" value="{{ old('installment') }}">
                                        <span style="color:red">@error('installment'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <label for="email" class="form-label">Work Permit Expiry <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="date" name="workpermitexpiry" id="workpermitexpiry" value="{{ old('loanend') }}">
                                        <span style="color:red">@error('workpermitexpiry'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <label for="email" class="form-label">Salary <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="number" name="salary" id="salary" value="0" value="{{ old('salary') }}">
                                        <span style="color:red">@error('salary'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-4">
                                        <label for="email" class="form-label">Office Charge <i class="bx bxs-star text-danger me-1"></i></label>
                                        <input class="form-control" type="number" name="officecharge" id="officecharge" value="{{ old('officecharge') }}">
                                        <span style="color:red">@error('officecharge'){{$message}}@enderror</span>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <button type="submit" class="btn btn-primary me-2">Save</button>
                                    <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                                </div>

                        </div>
                        </form>
                    </div>
                </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
<script src="{!! asset('assets/js/photo.js') !!}"></script>
</body>
</html>
