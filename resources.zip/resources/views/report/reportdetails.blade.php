<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script type="text/javascript">
        // $(document).ready(function(){
        //     window.print();
        // });
    </script>
    <link rel="stylesheet" media="screen" href="{{ URL::asset('assets/css/a4style.css') }}" />
    <link rel="stylesheet" media="print" href="{{ URL::asset('assets/css/a4printstyle.css') }}" />
</head>
<body>
<style>
    td:empty {
        border-bottom-color: white;
    }
</style>
@php $heading = 'Monthly Payment Details' @endphp
<h2>{{ config('app.name')}} {{ $heading }}</h2>
<h4>DATE: {{ Carbon\Carbon::parse($end_date)->format('d-m-Y') }}</h4>
@php
$SalaryDate = $LoanInstallmentDate = $OfficeCtransaction_chargeSALARYhargeDate = $TransactionCharge = 0;
foreach($array as $value){
    $title = $value->title;
    switch ($title) {
    case "SalaryDate":
        $SalaryDate = $value->value;
        break;
    case "LoanInstallmentDate":
        $LoanInstallmentDate = $value->value;
        break;
    case "OfficeChargeDate":
        $OfficeChargeDate = $value->value;
        break;
    case "TransactionCharge":
        $TransactionCharge = $value->value;
        break;
    default:
        break;
    }
}
@endphp

@if(empty($data))
</br>
<div class="alert warning">
  <strong>We apologize !</strong> <br>
  But it seems that we couldn't find any relevant data in our database for your search.  <br>
  Please try again with different keywords or check back later for updates.
</div>
@else
<table style="width:100px;" >
    <thead class="text-center">
    <th>CNTRL<br>NO.</th>
    <th>DRIVER'NAME & <br>MOBILE NO</th>
    <th>UBER</th>
    <th>CAREEM</th>
    <th>OTHER <br>PAYMENT</th>
    <th>TOTAL <br>AMOUNT</th>
    <th style="border-top: 1px solid white; border-bottom-color: white;"></th>
    <th>OTHER <br>EXPENSE</th>
    <th>SALARY &<br>CHARGE</th>
    <th>INSTALLMENT</th>
    <th>OFFICE<br>CHARGE</th>
    <th>TRAFFIC<BR>FINE</th>
    <th>SALIK</th>
    <th>TOTAL AMOUNT</th>
    <th  style="border-top: 1px solid white;border-bottom-color: white;"></th>
    <th>RETURN TO<br>OFFICE</th>
    <th>BALANCE AMOUNT<BR>RECEIVING</th>
    </tr>
    </thead>
    <tbody>
    @foreach ($data as $dt)
    @php
    $photo = $dt->photo;
    @endphp
    <tr>
        <td>
            @if($photo)
                <img src="{{ asset('upload/'.$photo)  }}" width="50px" height="50px">
            @endif
            <br><br>{{$dt->controlid}}</td>
        <td>
            <strong>{{ $dt->firstname . ' ' . $dt->lastname }}</strong><br>
            {{$dt->phone}}<br>
            {{$dt->address}}<br>
            LOAN END: {{ date('d/m/Y', strtotime($dt->loanend)) }}<br>
            WORK P.EXPIRY:{{date('d/m/Y', strtotime($dt->workpermitexpiry))}}
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    UBER<br>
                    @if(!empty($uber_maxdate))
                    {{ date('d/m/Y', strtotime($uber_maxdate)) }}
                    @endif
                    @if(!empty($uber_mindate))
                    {{ date('d/m/Y', strtotime($uber_mindate)) }}
                    @endif
                </div>
                <div class="bottom">{{$dt->total_earnings ? number_format($dt->total_earnings, 2) : '0.00'}}
                    </div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAREEM<br>
                    @if(!empty($careem_maxdate))
                    {{ date('d/m/Y', strtotime($careem_maxdate)) }}
                    @endif
                    @if(!empty($careem_mindate))
                    {{ date('d/m/Y', strtotime($careem_mindate)) }}
                    @endif
                </div>
                <div class="bottom">{{$dt->cash_balance ? floatval(str_replace(',', '', number_format($dt->cash_balance, 2))) : 0.00}}</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>PAYMENT
                </div>
                <div class="bottom">{{$dt->payment}}</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    TOTAL<br>AMOUNT
                </div>
                @php
                    $totalamount = floatval(str_replace(',', '',number_format($dt->total_earnings + $dt->cash_balance + $dt->payment, 2)));
                @endphp
                <div class="bottom">{{ $totalamount }}</div>
            </div>
        </td>
        <td></td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>EXPENSE
                </div>
                <div class="bottom">{{$dt->other}}</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    SALARY<br>
                    {{ $SalaryDate }}<br>
                </div>
                <div class="bottom">{{$dt->salary}}</div><br>
                <div class="bottom">{{$TransactionCharge}}</div>
            </div>
            <br>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BANK<br>
                    {{ $LoanInstallmentDate }}<br>
                </div>
                <div class="bottom">{{$dt->installment}}</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OFFICE<br>CHARGE
                    {{ $OfficeChargeDate }}<br>
                </div>
                <div class="bottom">{{$dt->officecharge}}</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAR EXPIRY<br>
                    {{ Carbon\Carbon::parse($dt->car_expiry_date)->format('d/m/Y') }} <br>
                    <br>
                    FINE<br>
                </div>
                <div class="bottom">{{$dt->traffic}}</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    D-{{$dt->salik_amount}}<br>
                    A-{{$dt->drab}}<br>
                </div>
                <div class="bottom">TO-<br>{{$dt->salik_amount + $dt->drab}}</div>
            </div>
        </td>
        <td>
            <div class="main">
            @php
             $totalexpence = $dt->other + $dt->salary ;
             $totalexpence = $totalexpence + $dt->traffic + $dt->officecharge ;

             $totalexpence= $totalexpence +  $dt->salik_amount + $dt->drab + $TransactionCharge;
             if (strtotime($dt->loanend) >= strtotime($end_date)) {
                  $totalexpence += $dt->installment;
            }

           $diff=$totalamount-$totalexpence;
            @endphp
                <div class="upper">{{ number_format($totalexpence, 2) }}

                    <br>
                </div>
            </div>
        </td>
        <td style="border-top: 1px solid; border-top-color: white;"></td>
        <td>
            <div class="main">
                <div class="upper">
                    RETURN<br> TO OFFICE
                </div>
                @if($diff<0)
                 <div class="bottom redtext" style="color: red">
                 {{ number_format($diff, 2)}}
                 </div>
                @else
                <div class="bottom" >0</div>
                @endif
        </div>


        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BALANCE<br>
                </div>
                @if($diff>0)
                    <div class="bottom"> {{ number_format($diff, 2)}}
                 </div>
                @else
                <div class="bottom" >0</div>
                @endif
            </div>
        </td>
    </tr>
    @endforeach

    </tbody>
</table>
@endif
<h5><a href="{{ route('report') }}" class="btn btn-default">Back</a> &nbsp;
    <a href= "#" onClick="window.print(); return false;" class="btn btn-default">Print</a></h5>

</body>
</html>
