<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free"
>
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <h4 class="fw-bold py-0 mb-0">Report</h4>
                    <div class="card mb-5 mt-5">
                        <h5 class="card-header">Details</h5>
                        <div class="card-body">
                            <form action="{{ route('createreport') }}" method="POST" enctype="multipart/form-data">
                                @csrf        
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <label for="date" class="form-label">Start Date</label>
                                        <input class="form-control" type="date" id="startdate" name="startdate"
                                               value="{{ date('Y-m-d') }}" value="{{ old('date') }}">
                                        <span style="color:red">@error('startdate'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="date" class="form-label">End Date</label>
                                        <input class="form-control" type="date" id="enddate" name="enddate"
                                               value="{{ date('Y-m-d') }}" value="{{ old('enddate') }}">
                                        <span style="color:red">@error('enddate'){{$message}}@enderror</span>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <div class="spinner-border text-primary me-2" role="status" id="loadDiv" style="display: none">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <button type="submit" class="btn btn-primary me-2" onclick="$(this).hide();$('#loadDiv').show();">Submit</button>
                                    <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
