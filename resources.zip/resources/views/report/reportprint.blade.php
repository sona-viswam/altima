<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script type="text/javascript">
        // $(document).ready(function(){
        //     window.print();
        // });
    </script>
    <link rel="stylesheet" media="screen" href="{{ URL::asset('assets/css/a4style.css') }}" />
    <link rel="stylesheet" media="print" href="{{ URL::asset('assets/css/a4printstyle.css') }}" />
</head>
<body>
@php $heading = 'Monthly Payment Details' @endphp
<h2>{{ config('app.name')}} {{ $heading }}</h2>
<h4>DATE: 28-02-2023 </h4>

<table style="width:100px;" >
    <thead class="text-center">
    <th>CNTRL<br>NO.</th>
    <th>DRIVER'NAME & <br>MOBILE NO</th>
    <th>UBER</th>
    <th>CAREEM</th>
    <th>OTHER <br>PAYMENT</th>
    <th>TOTAL <br>AMOUNT</th>
    <th></th>
    <th>OTHER <br>EXPENSE</th>
    <th>SALARY &<br>CHARGE</th>
    <th>INSTALLMENT</th>
    <th>OFFICE<br>CHARGE</th>
    <th>TRAFFIC<BR>FINE</th>
    <th>SALIK</th>
    <th>TOTAL AMOUNT</th>
    <th></th>
    <th>RETURN TO<br>OFFICE</th>
    <th>BALANCE AMOUNT<BR>RECEIVING</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td><img src="{{ asset('assets/img/avatars/1.png')  }}" width="50px" height="50px">
        <br><br>AL-21</td>
        <td>
            <strong>{{ strtoupper('Muhammed Arshad') }}</strong><br>
            0509654041<br>
            MALIBU 6/73252<br>
            LOAN END:15/01/24<br>
            WORK P.EXPIRY:05/01/24
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    UBER<br>
                    02/01/23<br>
                    29/01/23<br>
                </div>
                <div class="bottom">663</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAREEM<br>
                    01/01/23<br>
                    28/01/23<br>
                </div>
                <div class="bottom">359</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>PAYMENT
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    TOTAL<br>AMOUNT
                </div>
                <div class="bottom">1022</div>
            </div>
        </td>
        <td></td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>EXPENSE
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    SALARY<br>
                    31-01-23<br>
                </div>
                <div class="bottom">10</div>
            </div><br>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BANK<br>
                    15-02-23<br>
                </div>
                <div class="bottom">2809</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OFFICE<br>CHARGE
                    15-02-23<br>
                </div>
                <div class="bottom">500</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAR EXPIRY<br>
                    18/01/23<br>
                    <br>
                    FINE<br>
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    D-24<br>
                    A-0<br>
                </div>
                <div class="bottom">TO-<br>24</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    0<br>
                </div>
            </div>
        </td>
        <td></td>
        <td>
            <div class="main">
                <div class="upper">
                    RETURN<br> TO OFFICE
                </div>
                <div class="bottom redtext" style="color: red">-2321</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BALANCE<br>
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
    </tr>

{{--    Repeating loop starts--}}
    <tr>
        <td><img src="{{ asset('assets/img/avatars/5.png')  }}" width="50px" height="50px">
            <br><br>AL-21</td>
        <td>
            <strong>{{ strtoupper('Navas') }}</strong><br>
            0502387484<br>
            MALIBU 9/43086<br>
            LOAN END:25/02/24<br>
            WORK P.EXPIRY:14/02/24
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    UBER<br>
                    02/01/23<br>
                    29/01/23<br>
                </div>
                <div class="bottom">5076</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAREEM<br>
                    01/01/23<br>
                    28/01/23<br>
                </div>
                <div class="bottom">3954</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>PAYMENT
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    TOTAL<br>AMOUNT
                </div>
                <div class="bottom">9030</div>
            </div>
        </td>
        <td></td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>EXPENSE
                </div>
                <div class="bottom">11</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    SALARY<br>
                    31-01-23<br>
                </div>
               <div class="bottom">6000<br>10</div>
            </div><br>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BANK<br>
                    25-01-23<br>
                </div>
                <div class="bottom">2055</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OFFICE<br>CHARGE
                    25-01-23<br>
                </div>
                <div class="bottom">500</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAR EXPIRY<br>
                    02/02/23<br>
                    <br>
                    FINE<br>
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    D-140<br>
                    A-200<br>
                </div>
                <div class="bottom">TO-<br>340</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                   0
                </div>
            </div>
        </td>
        <td></td>
        <td>
            <div class="main">
                <div class="upper">
                    RETURN<br>TO OFFICE
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BALANCE<br>
                </div>
                <div class="bottom">114</div>
            </div>
        </td>
    </tr>
    <tr>
        <td><img src="{{ asset('assets/img/avatars/7.png')  }}" width="50px" height="50px">
            <br><br>AL-21</td>
        <td>
            <strong>{{ strtoupper('Shafi') }}</strong><br>
            0505913988<br>
            GMC YUKON<br>
            50/98322<br>
            LOAN END:15/01/25<br>
            WORK P.EXPIRY:16/02/24
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    UBER<br>
                    02/01/23<br>
                    29/01/23<br>
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAREEM<br>
                    01/01/23<br>
                    28/01/23<br>
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>PAYMENT
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    TOTAL<br>AMOUNT
                </div>
                <div class="bottom">12300</div>
            </div>
        </td>
        <td></td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>EXPENSES
                </div>
                <div class="bottom">2188</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    SALARY<br>
                    31-01-23<br>
                </div>
                <div class="bottom">6000<br>10</div>
            </div><br>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BANK<br>
                    15-02-23<br>
                </div>
                <div class="bottom">2809</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OFFICE<br>CHARGE
                    15-02-23<br>
                </div>
                <div class="bottom">500</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAR EXPIRY<br>
                    12/01/23<br>
                    <br>
                    FINE<br>
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    D-220<br>
                    A-116<br>
                </div>
                <div class="bottom">TO-<br>336</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    0
                </div>
            </div>
        </td>
        <td></td>
        <td>
            <div class="main">
                <div class="upper">
                    RETURN<br>TO OFFICE
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BALANCE<br>
                </div>
                <div class="bottom">49087</div>
            </div>
        </td>
    </tr>
    <tr>
        <td><img src="{{ asset('assets/img/avatars/6.png')  }}" width="50px" height="50px">
            <br><br>AL-21</td>
        <td>
            <strong>{{ strtoupper('Aisha Begam') }}</strong><br>
            0502387484<br>
            MALIBU 9/43086<br>
            LOAN END:25/02/24<br>
            WORK P.EXPIRY:14/02/24
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    UBER<br>
                    02/01/23<br>
                    29/01/23<br>
                </div>
                <div class="bottom">5076</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAREEM<br>
                    01/01/23<br>
                    28/01/23<br>
                </div>
                <div class="bottom">3954</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>PAYMENT
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    TOTAL<br>AMOUNT
                </div>
                <div class="bottom">9030</div>
            </div>
        </td>
        <td></td>
        <td>
            <div class="main">
                <div class="upper">
                    OTHER<br>EXPENSE
                </div>
                <div class="bottom">11</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    SALARY<br>
                    31-01-23<br>
                </div>
                <div class="bottom">6000<br>10</div>
            </div><br>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BANK<br>
                    25-01-23<br>
                </div>
                <div class="bottom">2055</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    OFFICE<br>CHARGE
                    25-01-23<br>
                </div>
                <div class="bottom">500</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    CAR EXPIRY<br>
                    02/02/23<br>
                    <br>
                    FINE<br>
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    D-140<br>
                    A-200<br>
                </div>
                <div class="bottom">TO-<br>340</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    0
                </div>
            </div>
        </td>
        <td></td>
        <td>
            <div class="main">
                <div class="upper">
                    RETURN<br>TO OFFICE
                </div>
                <div class="bottom">0</div>
            </div>
        </td>
        <td>
            <div class="main">
                <div class="upper">
                    BALANCE<br>
                </div>
                <div class="bottom">114</div>
            </div>
        </td>
    </tr>

{{--    Repeating loop ends--}}
    </tbody>
</table>
<h5><a href="#"class="btn btn-default">Back</a> &nbsp;
    <a href= "#" onClick="window.print(); return false;" class="btn btn-default">Print</a></h5>

</body>
</html>

