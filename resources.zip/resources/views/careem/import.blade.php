<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free"
>
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <h4 class="fw-bold py-0 mb-0">Careem Import</h4>
                    @include('message')
                    <div class="card mb-5 mt-5">
                        <h5 class="card-header">Details</h5>
                        <div class="card-body">
                            <form action="{{ route('careemimport') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <input type="hidden" name="type" value="darb">
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <label for="date" class="form-label">File</label>
                                        <input type="file" name="file" class="form-control">
                                        <span style="color:red">@error('file'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="date" class="form-label">Import Date</label>
                                        <input class="form-control" type="date" id="import_date" name="import_date"
                                               value="{{ date('Y-m-d') }}" value="{{ old('import_date') }}">
                                        <span style="color:red">@error('import_date'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="date" class="form-label">Report Month</label>
                                        <input class="form-control" type="month" id="report_month" name="report_month"
                                            value="{{ date('Y-m') }}" value="{{ old('report_month') }}">
                                        <span style="color:red">@error('report_month'){{$message}}@enderror</span>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <div class="spinner-border text-primary me-2" role="status" id="loadDiv" style="display: none">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <button type="submit" class="btn btn-primary me-2" onclick="$(this).hide();$('#loadDiv').show();">Save</button>
                                    <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
