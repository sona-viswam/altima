<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <link rel="stylesheet" media="screen" href="{{ URL::asset('assets/css/a4style.css') }}" />
    <link rel="stylesheet" media="print" href="{{ URL::asset('assets/css/a4printstyle.css') }}" />
</head>
<body>
<h2>{{ config('app.name')}}</h2>
<h4>Careem Imported Report </h4>
<table style="width:80%;" >
    <thead>
    <th>#</th>
    <th>Captain Id</th>
    <th>Captain Name</th>
    <th>Phone Number</th>
    <th>Cash Balance</th>
    </thead>
    <tbody>
    @php($i=0)
    @forelse($data  as $key => $value)
        <tr>
            <td class="centertext">{{ ++$i }}</td>
            <td>{{ $value->captain_id }}</td>
            <td>{{ $value->captain_name }}</td>
            <td>{{ $value->phone_number }}</td>
            <td class="righttext">{{ $value->cash_balance }}</td>
        </tr>
    @empty
        <tr>
            <td class ="text-center text-secondary mt-2" colspan="14">No data available now</td>
        </tr>
    @endforelse
    </tbody>
</table>
<h5>
    <div class="spinner-border text-primary me-2" role="status" id="loadDiv" style="display: none">
        <span class="visually-hidden">Loading...</span>
    </div>
    <a href="{{ route('savecareemimport') }}"class="btn btn-default" onclick="$(this).hide();$('#loadDiv').show();">Save</a> &nbsp;
    <a href="{{ route('careemimport') }}"class="btn btn-default">Back</a> &nbsp;
    <a href= "#" onClick="window.print(); return false;" class="btn btn-default">Print</a></h5>
</body>
</html>

