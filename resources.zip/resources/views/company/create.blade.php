<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free"
>
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="card mb-4">
                        <h5 class="card-header">Company Details</h5>
                        <div class="card-body">
                            <form action="{{ route('company.store') }}" method="POST" enctype="multipart/form-data">@csrf
                                <input type="hidden" name="type" value="other">
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <label for="title" class="form-label">Title</label>
                                        <input type="text" class="form-control" id="title" name="title"
                                               value="{{ old('title') }}">
                                        <span style="color:red">@error('title'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="value" class="form-label">Value</label>
                                        <input type="text" class="form-control" id="value" name="value"
                                               value="{{ old('value') }}">
                                        <span style="color:red">@error('value'){{$message}}@enderror</span>
                                    </div>
                                </div>

                                <div class="mt-2">
                                    <button type="submit" class="btn btn-primary me-2">Save</button>
                                    <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
