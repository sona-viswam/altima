<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="index.html" class="app-brand-link">
              <span class="app-brand-logo demo">
                  <img src="{{ asset('assets/img/favicon/favicon.png')  }}">
              </span>
            <span class="app-brand-text demo menu-text fw-bolder">Altima Limousine</span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>
    <div class="menu-inner-shadow"></div>
    @php
        if (!isset($class)) {
            $class ='';
        }
    @endphp
    <ul class="menu-inner py-1">
        <!-- Dashboard -->
        <li class="menu-item {{ ($class === 'dashboard') ? 'active' : '' }}">
            <a href="{{ route('dashboard') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Dashboard</div>
            </a>
        </li>
        <li class="menu-item {{ (($class ==='uber')|| ($class ==='careem') ||($class==='salik')) ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-book-content"></i>
                <div data-i18n="Layouts">App Report</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item {{ ($class == 'uber') ? 'active' : '' }}">
                    <a href="{{ route('uberimport') }}" class="menu-link">
                        <div data-i18n="Without menu">Uber</div>
                    </a>
                </li>
                <li class="menu-item {{ ($class == 'careem') ? 'active' : '' }}">
                    <a href="{{ route('careemimport') }}" class="menu-link">
                        <div data-i18n="Without navbar">Careem</div>
                    </a>
                </li>
                <li class="menu-item {{ ($class == 'salik') ? 'active' : '' }}">
                    <a href="{{ route('salikimport') }}" class="menu-link">
                        <div data-i18n="Without navbar">Salik</div>
                    </a>
                </li>
            </ul>
        </li>
        <li class="menu-item {{ ($class ==='otherpayment') ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-credit-card"></i>
                <div data-i18n="Layouts">Payments</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item {{ ($class == 'otherpayment') ? 'active' : '' }}">
                    <a href="{{ route('otherpayment.index') }}" class="menu-link">
                        <div data-i18n="Container">Other</div>
                    </a>
                </li>
            </ul>
        </li>
        <li class="menu-item {{ (($class === 'darb') || ($class ==='traffic') || ($class ==='other')) ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-money"></i>
                <div data-i18n="Layouts">Expenses</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item {{ ($class == 'darb') ? 'active' : '' }}">
                    <a href="{{ route('darb.index') }}" class="menu-link">
                        <div data-i18n="Without menu">Darb</div>
                    </a>
                </li>
                <li class="menu-item {{ ($class == 'traffic') ? 'active' : '' }}">
                    <a href="{{ route('traffic.index') }}" class="menu-link">
                        <div data-i18n="Without navbar">Traffic</div>
                    </a>
                </li>
                <li class="menu-item {{ ($class == 'other') ? 'active' : '' }}">
                    <a href="{{ route('other.index') }}" class="menu-link">
                        <div data-i18n="Container">Other</div>
                    </a>
                </li>
            </ul>
        </li>

        <li class="menu-item {{ ($class === 'captain') ? 'active' : '' }}">
            <a href="{{ route('captain.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-user-circle"></i>
                <div data-i18n="Analytics">Captain</div>
            </a>
        </li>
        <li class="menu-item {{ ($class === 'report') ? 'active' : '' }}">
            <a href="{{ route('report') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bar-chart"></i>
                <div data-i18n="Analytics">Report</div>
            </a>
        </li>
        <li class="menu-item {{ ($class === 'company') ? 'active' : '' }}">
            <a href="{{ route('company.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-square"></i>
                <div data-i18n="Analytics">Company</div>
            </a>
        </li>
        <li class="menu-item {{ ($class === 'user') ? 'active' : '' }}">
            <a href="{{ route('user.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div data-i18n="Analytics">User</div>
            </a>
        </li>
    </ul>
</aside>
