<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free">
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <h4 class="fw-bold py-0 mb-4">Account</h4>
                    @include('message')
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card mb-4">
                                <h5 class="card-header">Profile Details</h5>
                                <div class="card-body">
                                    <form action="{{ route('user.updateprofile') }}"  method="POST">@csrf
                                        <div class="row">
                                            <div class="mb-3 col-md-6">
                                                <label for="name" class="form-label">Name</label>
                                                <input class="form-control" type="text" id="name" name="name" value="{{ $data[0]->name }}" autofocus="">
                                                @if ($errors->has('name'))
                                                    <span class="text-sm text-danger">{{ $errors->first('name') }}</span>
                                                @endif
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="name" class="form-label">Email</label>
                                                <input class="form-control" type="text" id="name" name="email" value="{{ $data[0]->email }}" autofocus="">
                                                @if ($errors->has('email'))
                                                    <span class="text-sm text-danger">{{ $errors->first('email') }}</span>
                                                @endif
                                            </div>
{{--                                            <span style="color:red">@error('firstname'){{$message}}@enderror</span>--}}
                                            <div class="mb-3 col-md-6">
                                                <label for="lastName" class="form-label">Password</label>
                                                <input class="form-control" type="password" name="password" id="password" value="{{ $data[0]->password }}">
                                                <input class="form-control" type="hidden" name="oldpassword" id="oldpassword" value="{{ $data[0]->password }}">
                                                @if ($errors->has('password'))
                                                    <span class="text-sm text-danger">{{ $errors->first('password') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="mt-2">
                                            <button type="submit" class="btn btn-primary me-2"> Save </button>
                                            <button type="reset" class="btn btn-outline-secondary"> Cancel </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
