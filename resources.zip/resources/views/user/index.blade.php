<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free">
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <h4 class="fw-bold py-0 mb-0">Users
                        <span style="float: right;">
                                   <a href="{{ route('user.create') }}" class="btn btn-primary tn-sm mt-2"
                                   data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="top"
                                   data-bs-html="true" title="" data-bs-original-title="<span> New User </span>">
                                    <span class="tf-icons bx bx-plus-circle"></span>&nbsp; New User</a>
                        </span>
                    </h4>
                    @include('message')
                    <div class="card mt-5">
                        <h5 class="card-header">Data</h5>
                        <div class="table-responsive text-nowrap">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                @php $i = $data->perPage() * ($data->currentPage() - 1); @endphp
                                @forelse($data as $user)
                                <tr>
                                    <td>{{ ++$i }}</td>
                                    <td>{{ $user->name }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>
                                        <a href="{{ route('user.show',$user->id) }}" title="View"><i class="bx bx-show-alt btn-outline-primary me-1"></i> </a>
                                        <a href="{{ route('user.edit',$user->id) }}" title="Edit"><i class="bx bx-edit-alt btn-outline-success me-1"></i> </a>
                                        <a href="#" title="Delete" onclick="deleteuser(this, '{{ route('user.destroy',$user->id) }}');"><i class="bx bx-trash btn-outline-danger me-1"></i> </a>
                                    </td>
                                </tr>
                                @empty
                                    <tr class="table-primary">
                                        <td class ="text-center mt-2" colspan="6">No data available now</td>
                                    </tr>
                                @endforelse
                                <tr>
                                    <td colspan="6">{{ $data->links('pagination::bootstrap-4') }}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                @include('delete')
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
