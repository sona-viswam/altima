<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free">
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <h4 class="fw-bold py-0 mb-4">Traffic Expense</h4>
                    @include('message')
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card mb-4">
                                <h5 class="card-header">Details</h5>
                                <div class="card-body">
                                        <div class="row">
                                               <div class="mb-3 col-md-6">
                                                <label for="name" class="form-label">Date : </label>
                                                <span class="mb-0">{{ $expense->date }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="password" class="form-label">Captain : </label>
                                                <span class="mb-0">{{ $expense->mycaptain?->fullname }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Amount : </label>
                                                <span class="mb-0">{{ $expense->amount }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Notes : </label>
                                                <span class="mb-0">{{ $expense->note }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Created By : </label>
                                                <span class="mb-0">{{ $expense->mycreateduser?->name}}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Updatd By : </label>
                                                <span class="mb-0">{{ $expense->myupdateduser?->name}}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Created On : </label>
                                                <span class="mb-0">{{ date('d M Y', strtotime($expense->created_at)) }}</span>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="email" class="form-label">Updated On : </label>
                                                <span class="mb-0">{{ date('d M Y', strtotime($expense->updated_at)) }}</span>
                                            </div>
                                            <div class="mt-2">
                                                <a class="btn btn-outline-primary" href="{{ route('traffic.index') }}"> Back</a>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
