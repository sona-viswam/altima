<!DOCTYPE html>
<html
    lang="en"
    class="light-style layout-menu-fixed"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free"
>
<head>
    @include('header')
</head>
<body>
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
        @include('menu')
        <div class="layout-page">
            @include('topbar')
            <div class="content-wrapper">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="card mb-4">
                        <h5 class="card-header">Traffic Expense</h5>
                        <div class="card-body">
                            <form action="{{ route('traffic.store') }}" method="POST" enctype="multipart/form-data">@csrf
                                <input type="hidden" name="type" value="traffic">
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <label for="date" class="form-label">Date</label>
                                        <input class="form-control" type="date" id="date" name="date"
                                               value="{{ date('Y-m-d') }}" value="{{ old('date') }}">
                                        <span style="color:red">@error('date'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label" for="country">Captain</label>
                                        <select id="captain" name="captain" class="select2 form-select">
                                            <option value="" disabled> --- Select --- </option>
                                            @foreach($captain as $value)
                                            <option value="{{ $value->id }}">{{ $value->fullname }}</option>
                                            @endforeach
                                        </select>
                                        <span style="color:red">@error('captain'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="salary" class="form-label">Amount</label>
                                        <input type="text" class="form-control" id="amount" name="amount"
                                               maxlength="6" value="{{ old('amount') }}">
                                        <span style="color:red">@error('amount'){{$message}}@enderror</span>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="note" class="form-label">Notes</label>
                                        <input type="text" class="form-control" id="note" name="note"
                                               value="{{ old('note') }}">
                                        <span style="color:red">@error('note'){{$message}}@enderror</span>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <button type="submit" class="btn btn-primary me-2">Save</button>
                                    <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @include('footer')
            </div>
        </div>
    </div>
</div>
@include('tail')
</body>
</html>
