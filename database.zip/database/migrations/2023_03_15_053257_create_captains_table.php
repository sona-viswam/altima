<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('captain', function (Blueprint $table) {
            $table->id();
            $table->string('uuid');
            $table->bigInteger('captainid');
            $table->string('firstname');
            $table->string('lastname')->nullable();
            $table->string('email', 100)->unique()->nullable();
            $table->date('dob')->nullable();
            $table->integer('phone');
            $table->enum('gender', ['male', 'female', 'other']);
            $table->string('address')->nullable();
            $table->string('photo')->nullable();
            $table->decimal('salary', 30, 2);
            $table->string('vehicle'); 
            $table->date('car_expiry_date');
            $table->string('plate');
            $table->date('loanend')->nullable();
            $table->date('workpermitexpiry');
            $table->enum('status', ['active', 'inactive']);
            $table->bigInteger('created_by');
            $table->bigInteger('updated_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('captain');
    }
};
