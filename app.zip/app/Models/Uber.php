<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Uber extends Model
{
    use HasFactory;

    protected $table = 'uber';

    protected $fillable = [
        'driver_uuid',
        'driver_first_name',
        'driver_surname',
        'total_earnings',
        'refunds_expenses',
        'payouts_cash_collected',
        'paid_to_third_parties',
        'batch',
        'import_date',
        'document_date',
        'created_by',
        'updated_by',
    ];

    public static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            $model->created_by = Auth::id();
            $model->updated_by = Auth::id();
        });
    }


    public function mycreateduser(){
        return $this->belongsTo(User::class, 'created_by');
    }
    public function myupdateduser(){
        return $this->belongsTo(User::class, 'updated_by');
    }
}
