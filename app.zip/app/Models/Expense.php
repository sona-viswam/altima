<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Expense extends Model
{
    use HasFactory;

    protected $table = 'expense';

    protected $fillable = [
        'date',
        'captain',
        'type',
        'amount',
        'note',
        'created_by',
        'updated_by',
    ];
    public function mycaptain(){
        return $this->belongsTo(Captain::class, 'captain');
    }
    public function mycreateduser(){
        return $this->belongsTo(User::class, 'created_by');
    }
    public function myupdateduser(){
        return $this->belongsTo(User::class, 'updated_by');
    }
}
