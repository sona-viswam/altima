<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Captain extends Model
{
    use HasFactory;

    protected $table = 'captain';

    protected $fillable = [
        'controlid',
        'uuid',
        'captainid',
        'firstname',
        'lastname',
        'email',
        'dob',
        'phone',
        'gender',
        'address',
        'photo',
        'salary',
        'officecharge',
        'status',
        'vehicle',
        'car_expiry_date',
        'plate',
        'loanend',
        'workpermitexpiry',
        'installment',
        'created_by',
        'updated_by',
    ];

    public function getFullNameAttribute(){
        return ucfirst($this->firstname) . ' ' . ucfirst($this->lastname);
    }
    public function mycreateduser(){
        return $this->belongsTo(User::class, 'created_by');
    }
    public function myupdateduser(){
        return $this->belongsTo(User::class, 'updated_by');
    }
}
