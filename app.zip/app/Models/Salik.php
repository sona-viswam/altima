<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Salik extends Model
{
    use HasFactory;
    protected $table = 'salik';

    protected $fillable = [
       // 'date',
        'tag',
        'plate',
        'amount',
        'batch',
        'import_date',
        'document_date',
        'created_by',
        'updated_by',
    ];
    public static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            $model->created_by = Auth::id();
            $model->updated_by = Auth::id();
        });
    }



}
