<?php

namespace App\Http\Controllers;

use App\Imports\SalikImport;
use App\Models\Salik;
use App\Models\SalikTemp;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class SalikImportController extends Controller
{
    public $class = "salik";
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function index()
    {
        $class = $this->class;
        SalikTemp::truncate();
        return view('salik.import', compact('class'));
    }
     /**
     * Write code on Method
     *
     * @return response()
     */
    public function store(Request $request)
    {
        $class = $this->class;
        $validatedData = $request->validate( [
            'file'=> 'required|mimes:xlsx, csv, xls',
            'import_date'=> 'required|date|unique:salik',
            'report_month'=> 'required',
        ]);
        SalikTemp::truncate();
        Excel::import(new SalikImport, request()->file('file'));
        $import_date = $request->input('import_date');
        $arr1 = explode("-",$import_date);
        $m1 = $arr1[1];
        $y1 = $arr1[0];
        $report_month = $request->input('report_month');
        $arr2 = explode("-", $report_month);
        $m2 = $arr2[1];
        $y2 = $arr2[0];
        if(($m1 == $m2) && ($y1 == $y2)){
            $document_date = $import_date;
        }else{
            $lastdateofmonth = Carbon::create($y2, $m2)->lastOfMonth()->format('Y-m-d');
            $document_date = $lastdateofmonth;
        }
        SalikTemp::query()->update(['import_date' => $import_date, 'document_date' => $document_date]);        
        $data = SalikTemp::get();
        return view('salik.show', compact('data', 'class'))
            ->with('success', 'Salik Report Imported Successfully.');
    }
    public function save()
    {
        $now = Carbon::now();
        $currentTime = $now->timestamp;
        $formatedTime = $now->format('Y-m-d h:i:s');
        $myid = auth()->user()->id; 
        $table1Data = SalikTemp::get();
        $table2Data = [];
        foreach ($table1Data as $data) {
            $table2Data[] = [
               'date' => $data->date,
                'plate' => $data->plate,
                'tag' => $data->tag,
                'amount'=> $data->amount,
                'batch'=> $currentTime,
                'import_date' => $data->import_date,
                'document_date' => $data->document_date,
                'created_by'=> $myid,
                'updated_by'=> $myid,
                'created_at'=> $formatedTime,
                'updated_at'=> $formatedTime,
            ];
        }
        Salik::insert($table2Data);
        SalikTemp::truncate();
        return redirect()->route('salikimport')->with('success','Salik Report has been imported successfully.');
    }

}
