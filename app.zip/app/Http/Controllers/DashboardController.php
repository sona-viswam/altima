<?php

namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\Captain;
use App\Models\Expense;
use App\Models\Order;
use App\Models\Payments;
use App\Models\PaymentTypes;
use Illuminate\Http\Request;
use Carbon\Carbon;


class DashboardController extends Controller
{
    public $class = "dashboard";

    public function dashboard(){
        $class = $this->class;
        $startDate = Carbon::now(); //returns current day
        $firstDay = $startDate->firstOfMonth()->format('Y-m-d'); 
        $endDay = $startDate->endOfMonth()->format('Y-m-d');  
        $captainCount = Captain::where('status','active')->count();
        $darbamount = Expense::where('type','darb')->whereBetween('date', [$firstDay, $endDay])
                        ->groupBy('type')->sum('amount');
        $trafficamount = Expense::where('type','traffic')->whereBetween('date', [$firstDay, $endDay])
                        ->groupBy('type')->sum('amount');      
        $otheramount = Expense::where('type','other')->whereBetween('date', [$firstDay, $endDay])
                        ->groupBy('type')->sum('amount');                           
        return view('dashboard',compact( 'class', 'captainCount', 'darbamount', 'trafficamount', 'otheramount'));
    }

}
