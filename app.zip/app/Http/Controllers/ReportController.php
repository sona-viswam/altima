<?php

namespace App\Http\Controllers;

use App\Models\Careem;
use App\Models\Company;
use App\Models\Salik;
use App\Models\Uber;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public $class = "report";
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $class = $this->class;
        return view('report.index', compact('class'));
    }
    public function createreport(request $request)
    {
        /** Developed by: Sona Rijesh....code starts*/
        $start_date = $request->input('startdate');
        $end_date = $request->input('enddate');

        $validatedData = $request->validate( [
            'startdate' => 'required|date_format:Y-m-d',
            'enddate' => 'required|date_format:Y-m-d|after_or_equal:startdate',
        ]);

        $array = Company::where('id','<=',5)->get();

        $careem_maxdate = Careem::whereBetween('document_date', [$start_date, $end_date])->max('document_date');
        $careem_mindate = Careem::whereBetween('document_date', [$start_date, $end_date])->min('document_date');
        if($careem_mindate){
            $careem_mindate = Carbon::createFromFormat('Y-m-d', $careem_mindate)->subDays(6)->format('Y-m-d');
        }        
        $uber_maxdate = Uber::whereBetween('document_date', [$start_date, $end_date])->max('document_date');
        $uber_mindate = Uber::whereBetween('document_date', [$start_date, $end_date])->min('document_date');      
        if($uber_mindate){
            $uber_mindate = Carbon::createFromFormat('Y-m-d', $uber_mindate)->subDays(6)->format('Y-m-d');
        }   
        /** Developed by: Sona Rijesh....code ends*/

        // $data = DB::table('captain')
        // ->leftJoin('expense', 'captain.id', '=', 'expense.captain')
        // ->select(
        //     'captain.controlid',
        //     'captain.id',
        //     'captain.firstname',
        //     'captain.lastname',
        //     'captain.captainid',
        //     'expense.captain',
        //     'captain.uuid',
        //     'captain.photo',
        //     'captain.address',
        //     'captain.car_expiry_date',
        //     'captain.loanend',
        //     'captain.workpermitexpiry',
        //     'captain.installment',
        //     'captain.officecharge',
        //     DB::raw("(SELECT SUM(cash_balance) FROM careem WHERE careem.document_date BETWEEN ? AND ? AND captain_id = captain.captainid) AS cash_balance"),
        //     DB::raw("(SELECT SUM(total_earnings) FROM uber WHERE uber.document_date BETWEEN ? AND ? AND driver_uuid = captain.uuid) AS total_earnings"),
        //     DB::raw("(SELECT SUM(amount) FROM payment WHERE captain = captain.id) AS payment"),
        //     DB::raw("(SELECT SUM(amount) FROM salik WHERE plate = captain.plate) AS salik_amount"),
        //     DB::raw("COALESCE(SUM(CASE WHEN expense.type = 'other' THEN expense.amount ELSE 0 END), 0) AS other"),
        //     DB::raw("COALESCE(SUM(CASE WHEN expense.type = 'traffic' THEN expense.amount ELSE 0 END), 0) AS traffic"),
        //     DB::raw("COALESCE(SUM(CASE WHEN expense.type = 'darb' THEN expense.amount ELSE 0 END), 0) AS drab"),
        //     'captain.salary',
        //     'captain.phone',
        //     'captain.email'
        // )
        // ->groupBy(
        //     'captain.controlid',
        //     'captain.id',
        //     'captain.firstname',
        //     'captain.lastname',
        //     'captain.captainid',
        //     'expense.captain',
        //     'captain.uuid',
        //     'captain.photo',
        //     'captain.plate',
        //     'captain.salary',
        //     'captain.phone',
        //     'captain.email',
        //     'captain.address',
        //     'captain.car_expiry_date',
        //     'captain.loanend',
        //     'captain.workpermitexpiry',
        //     'captain.installment',
        //     'captain.officecharge'
        // )
        // ->get();

        $data = DB::table('captain')
        ->leftJoin('expense', 'captain.id', '=', 'expense.captain')
        ->select(
            'captain.controlid',
            'captain.id',
            'captain.firstname',
            'captain.lastname',
            'captain.captainid',
            'expense.captain',
            'captain.uuid',
            'captain.photo',
            'captain.address',
            'captain.car_expiry_date',
            'captain.loanend',
            'captain.workpermitexpiry',
            'captain.installment',
            'captain.officecharge'
        )
        ->selectRaw(
            "(SELECT SUM(cash_balance) FROM careem WHERE careem.document_date BETWEEN ? AND ? AND captain_id=captain.captainid ) AS cash_balance",
            [$start_date, $end_date]
        )
        ->selectRaw(
            "(SELECT SUM(total_earnings) FROM uber WHERE uber.document_date BETWEEN ? AND ? AND  driver_uuid=captain.uuid)AS total_earnings",
            [$start_date, $end_date]
        )
        ->addSelect(
            DB::raw("(SELECT SUM(amount) FROM payment WHERE captain=captain.id)AS payment"),
            DB::raw("(SELECT SUM(amount) FROM salik WHERE plate=captain.plate)AS salik_amount"),
            DB::raw("COALESCE(SUM(CASE WHEN expense.type = 'other' THEN expense.amount ELSE 0 END), 0) AS other"),
            DB::raw("COALESCE(SUM(CASE WHEN expense.type = 'traffic' THEN expense.amount ELSE 0 END), 0) AS traffic"),
            DB::raw("COALESCE(SUM(CASE WHEN expense.type = 'darb' THEN expense.amount ELSE 0 END), 0) AS drab"),
            'captain.salary',
            'captain.phone',
            'captain.email'
        )
        //->where('expense.captain', '=', 17)
        ->groupBy(
            'captain.controlid',
            'captain.id',
            'captain.firstname',
            'captain.lastname',
            'captain.captainid',
            'captain.uuid',
            'captain.photo',
            'captain.plate',
            'captain.salary',
            'captain.phone',
            'captain.email',
            'captain.address',
            'captain.car_expiry_date',
            'captain.loanend',
            'captain.workpermitexpiry',
            'captain.installment',
             'captain.officecharge',
             'expense.captain'
        )->get();


        return view('report.reportdetails',  compact('data', 'array', 'start_date', 'end_date', 
                    'careem_maxdate', 'careem_mindate', 'uber_maxdate', 'uber_mindate'));
    }


}
