<?php

namespace App\Http\Controllers;

use App\Models\Company;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
    public $class = "company";
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $class = $this->class;
        $data = Company::orderBy('id','asc')->paginate($this->pageno);
        return view('company.index', compact( 'data', 'class'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $class = $this->class;
        return view('company.create', compact( 'class'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $validatedData = $request->validate( [
            'title' => 'required',
            'value' => 'required',
        ]);
        Company::create($validatedData);
        return redirect()->route('company.index')->with('success','Company data has been created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Company $company)
    {
        $class = $this->class;
        return view('company.show',compact('company', 'class'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Company $company)
    {
        $class = $this->class;
        return view('company.edit', compact( 'company','class'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Company $company)
    {
        $updateData = $request->validate( [
            'title' => 'required',
            'value' => 'required',
        ]);
        Company::whereId($company->id)->update($updateData);
        return redirect()->route('company.index')->with('success','Company data has been updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        Company::findOrFail($id)->delete();
        $msg = 'Company Detail has been deleted successfully';
        $msgType='success';
        return redirect()->route('company.index')->with($msgType,$msg);
    }

}
