<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public $class = "dashboard";

    public function login()
    {
        return view('login');
    }
    public function doLogin(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->intended('dashboard');
        }
        return back()->withErrors([
            'error' => 'Oppes! You have entered invalid credentials',
        ]);
    }

    public function logout(){
        Auth::logout(); // logout user
//        return redirect(\URL::previous());
        return redirect('login');
    }

}
