<?php

namespace App\Http\Controllers;

use App\Models\Captain;
use App\Models\Payment;
use Illuminate\Http\Request;


class OtherPaymentController extends Controller
{
    public $class = "otherpayment";
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $class = $this->class;
        $type = 'other';
        $data = Payment::where('type',$type)->orderBy('id','desc')->paginate($this->pageno);
        return view('otherpayment.index', compact( 'data', 'class'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $class = $this->class;
        $captain = Captain::get(["id", "firstname", "lastname"]);
        return view('otherpayment.create', compact( 'class', 'captain'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate( [
            'date' => 'required',
            'captain' => 'required',
            'type' => 'required',
            'amount' => 'required',
            'note' => 'nullable',
        ]);
        $validatedData['created_by'] =  auth()->user()->id;
        Payment::create($validatedData);
        return redirect()->route('otherpayment.index')->with('success','Other Payment has been created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $class = $this->class;
        $data = Payment::find($id);
        return view('otherpayment.show',compact('data', 'class'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $class = $this->class;
        $captain = Captain::get(["id", "firstname", "lastname"]);
        $data = Payment::find($id);
        return view('otherpayment.edit', compact( 'data', 'captain','class'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $updateData = $request->validate([
            'date' => 'required',
            'captain' => 'required',
            'type' => 'required',
            'amount' => 'required',
            'note' => 'nullable',
        ]);
        $updateData['updated_by'] = auth()->user()->id;
        Payment::whereId($id)->update($updateData);
        return redirect()->route('otherpayment.index')->with('success','Other Payment has been updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        Payment::whereId($id)->delete();
        $msg = 'Other Payment has been deleted successfully';
        $msgType='success';
        return redirect()->route('otherpayment.index')->with($msgType,$msg);
    }
}
