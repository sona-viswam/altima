<?php

namespace App\Http\Controllers;

use App\Models\Captain;
use App\Models\User;
use Illuminate\Http\Request;


class UserController extends Controller
{
    public $class = "user";
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $class = $this->class;
        $data = User::orderBy('id','desc')->paginate($this->pageno);
        return view('user.index', compact( 'data', 'class'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $class = $this->class;
        return view('user.create', compact( 'class'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate( [
            'name' => 'required|min:4',
            'password' => 'required|min:6',
            'email' => 'required|email|unique:users,email',
        ]);
        $validatedData['created_by'] = $validatedData['updated_by'] = auth()->user()->id;
        User::create($validatedData);
        return redirect()->route('user.index')->with('success','User has been created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(User $user)
    {
        $class = $this->class;
        return view('user.show',compact('user', 'class'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        $class = $this->class;
        return view('user.edit', compact( 'user','class'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user)
    {
        $updateData = $request->validate([
            'name' => 'required|min:4',
            'password' => 'required|min:6',
            'email' => 'required|email|unique:users,email,'. $user->id,
        ]);
        $password = $request->input('password');
        $oldpassword = $request->input('oldpassword');
        if($oldpassword != $password){
            $updateData['password'] = bcrypt($password);
        }
        $updateData['updated_by'] = auth()->user()->id;
        User::whereId($user->id)->update($updateData);
        return redirect()->route('user.index')->with('success','User has been updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
       if(Captain::where('created_by', $id)->exists() ){
           $msg = 'Sorry, You cannot delete this record because it is already in use';
           $msgType='error';
       }else{
           User::whereId($id)->delete();
           $msg = 'Uset has been deleted successfully';
           $msgType='success';
       }
       return redirect()->route('user.index')->with($msgType,$msg);
    }

    public function profile()
    {
        $data = User::find(auth()->id())->get();
        return view('user.profile', compact( 'data'));
    }
    public function updateprofile(Request $request)
    {
        $id = auth()->id();
        $updateData = $request->validate( [
            'name' => 'required|min:4',
            'email' => 'required|email|unique:users,email,'. $id,
            'password'=>'required|min:6',
        ]);
        $password = $request->input('password');
        $oldpassword = $request->input('oldpassword');
//        dd($password.'-'.$oldpassword);
        if($oldpassword !== $password){
            $updateData['password'] = bcrypt($password);
        }
        User::whereId($id)->update($updateData);
        return redirect()->back()->with('success', 'Your profile have updated successfully');
    }
}
