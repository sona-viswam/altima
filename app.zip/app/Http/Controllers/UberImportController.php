<?php

namespace App\Http\Controllers;

use App\Models\Uber;
use App\Models\UberTmp;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Imports\UberImport;
use Maatwebsite\Excel\Facades\Excel;

class UberImportController extends Controller
{
    public $class = "uber";
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function index()
    {
        $class = $this->class;
        UberTmp::truncate();
        return view('uber.import', compact('class'));
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function store(Request $request)
    {
        $class = $this->class;
        $validatedData = $request->validate( [
            'file'=> 'required|mimes:xlsx,csv,xls',
            'import_date'=> 'required|date|unique:uber',
            'report_month'=> 'required',
        ]);
        UberTmp::truncate();
        Excel::import(new UberImport, request()->file('file'));
        $import_date = $request->input('import_date');
        $arr1 = explode("-",$import_date);
        $m1 = $arr1[1];
        $y1 = $arr1[0];
        $report_month = $request->input('report_month');
        $arr2 = explode("-", $report_month);
        $m2 = $arr2[1];
        $y2 = $arr2[0];
        if(($m1 == $m2) && ($y1 == $y2)){
            $document_date = $import_date;
        }else{
            $lastdateofmonth = Carbon::create($y2, $m2)->lastOfMonth()->format('Y-m-d');
            $document_date = $lastdateofmonth;
        }
        UberTmp::query()->update(['import_date' => $import_date, 'document_date' => $document_date]);        
        $data = UberTmp::get();
        return view('uber.show', compact('data', 'class'))
            ->with('success', 'Uber Report Imported Successfully.');
    }

    public function save()
    {
        $now = Carbon::now();
        $currentTime = $now->timestamp;
        $formatedTime = $now->format('Y-m-d h:i:s');
        $myid = auth()->user()->id;
        $table1Data = UberTmp::get();
        $table2Data = [];
        foreach ($table1Data as $data) {
            $table2Data[] = [
                'driver_uuid' => $data->driver_uuid,
                'driver_first_name' => $data->driver_first_name,
                'driver_surname' => $data->driver_surname,
                'total_earnings'=> $data->total_earnings,
                'refunds_expenses'=> $data->refunds_expenses,
                'payouts_cash_collected' => $data->payouts_cash_collected,
                'paid_to_third_parties'=> $data->paid_to_third_parties,
                'batch'=> $currentTime,
                'import_date' => $data->import_date,
                'document_date' => $data->document_date,
                'created_by'=> $myid,
                'updated_by'=> $myid,
                'created_at'=> $formatedTime,
                'updated_at'=> $formatedTime,
            ];
        }
        Uber::insert($table2Data);
        UberTmp::truncate();
        return redirect()->route('uberimport')->with('success','Uber Report has been imported successfully.');
    }
}
