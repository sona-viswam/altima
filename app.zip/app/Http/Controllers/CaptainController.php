<?php

namespace App\Http\Controllers;

use App\Models\Captain;
use App\Models\Expense;
use App\Models\Payment;
use App\Models\User;
use Faker\Core\File;
use Illuminate\Http\Request;


class CaptainController extends Controller
{
    public $class = "captain";
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $class = $this->class;
        $data = Captain::orderBy('id','desc')->paginate($this->pageno);
        return view('captain.index', compact( 'data', 'class'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $class = $this->class;
        return view('captain.create', compact( 'class'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $validatedData = $request->validate( [
            'photo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'controlid' => 'required',
            'uuid' => 'required',
            'captainid' => 'required|numeric',
            'firstname' => 'required|min:4',
            'lastname' => 'nullable',
            'email' => 'nullable|email|unique:captain,email',
            'dob' => 'nullable',
            'phone' => 'required',
            'gender' => 'required',
            'address' => 'nullable',
            'photo' => 'nullable',
            'salary' => 'required',
            'officecharge'=>'required', 
            'vehicle' => 'required',
            'car_expiry_date' => 'required',
            'plate' => 'required',
            'loanend' => 'nullable',
            'installment' => 'nullable',
            'workpermitexpiry' => 'required',
        ]);

        if ($request->has('photo')) {
            $fileName = time().'.'.$request->photo->extension();
            $request->photo->move(public_path('upload'), $fileName);
            $validatedData['photo'] = $fileName;
        }
        $validatedData['created_by'] = $validatedData['updated_by'] = auth()->user()->id;
        Captain::create($validatedData);
        return redirect()->route('captain.index')->with('success','Captain has been created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Captain $captain)
    {
        $class = $this->class;
        return view('captain.show',compact('captain', 'class'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Captain $captain)
    {
        $class = $this->class;
        return view('captain.edit', compact( 'captain','class'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Captain $captain)
    {
        $updateData = $request->validate( [
            'pictureFile' => 'nullabl|image|mimes:jpeg,png,jpg|max:2048',
            'controlid' => 'required',
            'uuid' => 'required',
            'captainid' => 'required|numeric',
            'firstname' => 'required|min:4',
            'lastname' => 'nullable',
            'email' => 'nullable|email|unique:captain,email,'. $captain->id,
            'dob' => 'nullable',
            'phone' => 'required',
            'gender' => 'required',
            'address' => 'nullable',
            'photo' => 'nullable',
            'salary' => 'required',
            'officecharge'=>'required',
            'vehicle' => 'required',
            'car_expiry_date' => 'required',
            'plate' => 'required',
            'loanend' => 'nullable',
            'installment' => 'nullable',
            'workpermitexpiry' => 'required',
        ]);

        if ($request->has('photo')) {

            $fileName = time().'.'.$request->photo->extension();
            $request->photo->move(public_path('upload'), $fileName);
            $updateData['photo'] = $fileName;
            $old_photo = $request->input('old_photo');
            if($old_photo){
                $image_path = public_path('upload').'/'.$old_photo;
                if (file_exists($image_path)) {
                    File::delete($image_path);
                }

            }

        }
      //  dd("p");
        $updateData['updated_by'] = auth()->user()->id;

        Captain::whereId($captain->id)->update($updateData);
        return redirect()->route('captain.index')->with('success','Captain has been updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
       if((Payment::where('captain', $id)->exists()) ||(Expense::where('captain', $id)->exists()) ){
           $msg = 'Sorry, You cannot delete this record because it is already in use';
           $msgType='error';
       }else{
           Captain::findOrFail($id)->delete();
           $msg = 'Captain has been deleted successfully';
           $msgType='success';
       }
       return redirect()->route('captain.index')->with($msgType,$msg);
    }

    public function captainimageupload(Request $request)
    {
//        $image_path = public_path('upload').'/'.auth()->user()->id.'jpg';
//        if (file_exists($image_path)) {
//            File::delete($image_path);
//        }

        $path =  public_path('upload').'/';
        $files = glob($path.auth()->user()->id.".{jpg,jpeg,png,gif}", GLOB_BRACE);
        foreach ($files as $image_path) {
            if (file_exists($image_path)) {
                File::delete($image_path);
            }
        }
        $imageName = auth()->user()->id.'.'.$request->pictureFile->extension();
        $request->pictureFile->move(public_path('images'), $imageName);
        return $imageName;
    }
}
