<?php

namespace App\Http\Controllers;

use App\Models\Captain;
use App\Models\Expense;
use Illuminate\Http\Request;


class DarbController extends Controller
{
    public $class = "darb";
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $class = $this->class;
        $type = 'darb';
        $data = Expense::where('type',$type)->orderBy('id','desc')->paginate($this->pageno);
        return view('darb.index', compact( 'data', 'class'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $class = $this->class;
        $captain = Captain::get(["id", "firstname", "lastname"]);
        return view('darb.create', compact( 'class', 'captain'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate( [
            'date' => 'required',
            'captain' => 'required',
            'type' => 'required',
            'amount' => 'required',
            'note' => 'nullable',
        ]);
        $validatedData['created_by'] =  auth()->user()->id;
        Expense::create($validatedData);
        return redirect()->route('darb.index')->with('success','Darb has been created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $class = $this->class;
        $expense = Expense::find($id);
        return view('darb.show',compact('expense', 'class'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $class = $this->class;
        $captain = Captain::get(["id", "firstname", "lastname"]);
        $expense = Expense::find($id);
        return view('darb.edit', compact( 'expense', 'captain','class'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $updateData = $request->validate([
            'date' => 'required',
            'captain' => 'required',
            'type' => 'required',
            'amount' => 'required',
            'note' => 'nullable',
        ]);
        $updateData['updated_by'] = auth()->user()->id;
        Expense::whereId($id)->update($updateData);
        return redirect()->route('darb.index')->with('success','Darb has been updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        Expense::whereId($id)->delete();
        $msg = 'Darb has been deleted successfully';
        $msgType='success';
        return redirect()->route('darb.index')->with($msgType,$msg);
    }
}
