<?php

namespace App\Http\Controllers;

use App\Models\Captain;
use App\Models\Expense;
use Illuminate\Http\Request;


class TrafficController extends Controller
{
    public $class = "traffic";
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $class = $this->class;
        $type = 'traffic';
        $data = Expense::where('type',$type)->orderBy('id','desc')->paginate($this->pageno);
        return view('traffic.index', compact( 'data', 'class'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $class = $this->class;
        $captain = Captain::get(["id", "firstname", "lastname"]);
        return view('traffic.create', compact( 'class', 'captain'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate( [
            'date' => 'required',
            'captain' => 'required',
            'type' => 'required',
            'amount' => 'required',
            'note' => 'nullable',
        ]);
        $validatedData['created_by'] =  auth()->user()->id;
        Expense::create($validatedData);
        return redirect()->route('traffic.index')->with('success','Traffic has been created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $class = $this->class;
        $expense = Expense::find($id);
        return view('traffic.show',compact('expense', 'class'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $class = $this->class;
        $captain = Captain::get(["id", "firstname", "lastname"]);
        $expense = Expense::find($id);
        return view('traffic.edit', compact( 'expense', 'captain','class'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $updateData = $request->validate([
            'date' => 'required',
            'captain' => 'required',
            'type' => 'required',
            'amount' => 'required',
            'note' => 'nullable',
        ]);
        $updateData['updated_by'] = auth()->user()->id;
        Expense::whereId($id)->update($updateData);
        return redirect()->route('traffic.index')->with('success','Traffic has been updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        Expense::whereId($id)->delete();
        $msg = 'Traffic has been deleted successfully';
        $msgType='success';
        return redirect()->route('traffic.index')->with($msgType,$msg);
    }
}
