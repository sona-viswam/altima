<?php

namespace App\Http\Controllers;

use App\Models\Careem;
use App\Models\CareemTmp;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Imports\CareemImport;
use Maatwebsite\Excel\Facades\Excel;

class CareemImportController extends Controller
{
    public $class = "careem";
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function index()
    {
        $class = $this->class;
        CareemTmp::truncate();
        return view('careem.import', compact('class'));
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function store(Request $request)
    {
        $class = $this->class;  
        $validatedData = $request->validate( [
            'file'=> 'required|mimes:xlsx, csv, xls',
            'import_date'=> 'required|date|unique:careem',
            'report_month'=> 'required',
        ]);
        CareemTmp::truncate();
        Excel::import(new CareemImport, request()->file('file'));
        $import_date = $request->input('import_date');
        $arr1 = explode("-",$import_date);
        $m1 = $arr1[1];
        $y1 = $arr1[0];
        $report_month = $request->input('report_month');
        $arr2 = explode("-", $report_month);
        $m2 = $arr2[1];
        $y2 = $arr2[0];
        if(($m1 == $m2) && ($y1 == $y2)){
            $document_date = $import_date;
        }else{
            $lastdateofmonth = Carbon::create($y2, $m2)->lastOfMonth()->format('Y-m-d');
            $document_date = $lastdateofmonth;
        }
        CareemTmp::query()->update(['import_date' => $import_date, 'document_date' => $document_date]);        
        $data = CareemTmp::get();
        return view('careem.show', compact('data', 'class'))
            ->with('success', 'Careem Report Imported Successfully.');
    }
    public function save()
    {
        $now = Carbon::now();
        $currentTime = $now->timestamp;
        $formatedTime = $now->format('Y-m-d h:i:s');
        $myid = auth()->user()->id;
        $table1Data = CareemTmp::get();
        $table2Data = [];
        foreach ($table1Data as $data) {
            $table2Data[] = [
                'captain_id' => $data->captain_id,
                'captain_name' => $data->captain_name,
                'phone_number' => $data->phone_number,
                'cash_balance' => $data->cash_balance,
                'batch'=> $currentTime,
                'import_date' => $data->import_date,
                'document_date' => $data->document_date,
                'created_by'=> $myid,
                'updated_by'=> $myid,
                'created_at'=> $formatedTime,
                'updated_at'=> $formatedTime,
            ];
        }
        Careem::insert($table2Data);
        CareemTmp::truncate();
        return redirect()->route('careemimport')->with('success','Careem Report has been imported successfully.');
    }
}
