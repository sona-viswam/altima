<?php

namespace App\Imports;

use App\Models\SalikTemp;
use Illuminate\Support\Collection;
use Carbon\Carbon;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use DateTime;

class SalikImport implements ToCollection,WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function collection(Collection $rows)
    {
        $groupedRows = [];
        $amount=4;

    foreach ($rows as $row) {
        $validator = Validator::make($row->toArray(), [
            'date' => 'required',
            'plate' => 'required',
            'tag' => 'required',
            'amount' => 'required',
        ]);

        if ($validator->fails()) {
            continue; // Skip the row if validation fails
        }

        $dateString = $row['date'];
        $dateTime = DateTime::createFromFormat('d-M-Y h:i:s A', $dateString);
        $formattedDate = $dateTime->format('Y-m-d');

        $plate = $row['plate'];
        $tag = $row['tag'];
        $amount = $row['amount'];

        $key = $plate . '_' . $tag;

        if (!isset($groupedRows[$key])) {
            $groupedRows[$key] = [
                'plate' => $plate,
                'tag' => $tag,
                'total_amount' => 0,
                'max_date' => null,
            ];
        }

        $groupedRows[$key]['total_amount'] += $amount;

        if ($groupedRows[$key]['max_date'] === null || $formattedDate > $groupedRows[$key]['max_date']) {
            $groupedRows[$key]['max_date'] = $formattedDate;
        }
    }

    // Save the grouped and aggregated rows
    foreach ($groupedRows as $groupedRow) {
        SalikTemp::create([
            'plate' => $groupedRow['plate'],
            'tag' => $groupedRow['tag'],
            'amount' => $groupedRow['total_amount'],
            'date' => $groupedRow['max_date'],
        ]);
    }
    }
}
