<?php

namespace App\Imports;

namespace App\Imports;

use App\Models\CareemTmp;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;


class CareemImport implements ToCollection, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function collection(Collection $rows)
    {

//        $newArray = array_map(function($arr) {
//            return [
//                'captainid' => $arr['captain_id'],
//                'captainname' => $arr['captain_name'],
//                'status' => $arr['status'],
//                'phone' => $arr['phone_number'],
//                'tier' => $arr['tier'],
//                'name' => $arr['name'],
//                'acceptance' => $arr['acceptance'],
//                'availability' => $arr['availability'],
//                'trips' => $arr['trips'],
//                'earnings' => $arr['earnings'],
//                'cash_payment' => $arr['cash_payment'],
//                'cash_balance' => $arr['cash_balance'],
//            ];
//        }, $rows->toArray());

//        dd($rows->toArray());

        Validator::make($rows->toArray(), [
            '*.captain_id' => 'required',
            '*.captain_name' => 'required',
            '*.phone_number' => 'required',
            '*.cash_balance' => 'required',
        ])->validate();

        foreach ($rows as $row) {
            CareemTmp::create([
                'captain_id' => $row['captain_id'],
                'captain_name' => $row['captain_name'],
                'phone_number' => $row['phone_number'],
                'cash_balance' => $row['cash_balance'],
            ]);
        }
    }

}
