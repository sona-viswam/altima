<?php

namespace App\Imports;

use App\Models\UberTmp;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;


class UberImport implements ToCollection, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function collection(Collection $rows)
    { 
        Validator::make($rows->toArray(), [
            '*.driver_uuid' => 'required',
            '*.driver_first_name' => 'required',
            '*.driver_surname' => 'required',
            '*.total_earnings' => 'nullable',
            '*.refunds_expenses' => 'nullable',
            '*.payouts:cash_collected' => 'nullable',
            '*.paid_to_third_parties' => 'nullable',
        ])->validate();

        foreach ($rows as $row) { 
            UberTmp::create([
                'driver_uuid' => $row['driver_uuid'],
                'driver_first_name' => $row['driver_first_name'],
                'driver_surname' => $row['driver_surname'],
                'total_earnings' => $row['total_earnings'],
                'refunds_expenses' => $row['refunds_expenses'],
                'payouts_cash_collected' => $row['payouts_cash_collected'],                
                'paid_to_third_parties' => $row['paid_to_third_parties'],
            ]);
        }
    }

}
